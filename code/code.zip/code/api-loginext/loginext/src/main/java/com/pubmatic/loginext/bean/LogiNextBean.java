package com.pubmatic.loginext.bean;

public interface LogiNextBean {

}
