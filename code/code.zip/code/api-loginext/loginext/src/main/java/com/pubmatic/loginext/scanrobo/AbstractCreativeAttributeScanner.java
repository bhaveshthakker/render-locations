package com.pubmatic.loginext.scanrobo;

public class AbstractCreativeAttributeScanner implements
		CreativeAttributeScanner {

}
