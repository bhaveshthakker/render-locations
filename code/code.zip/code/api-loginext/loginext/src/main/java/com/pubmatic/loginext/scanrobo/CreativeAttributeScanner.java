package com.pubmatic.loginext.scanrobo;

public interface CreativeAttributeScanner {	
}
